package proj;

import org.bouncycastle.jce.provider.BouncyCastleProvider;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.security.Security;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Base64;
import java.util.Arrays;

public class EncryptUserInput extends JFrame {

    private JTextField usernameField;
    private JPasswordField passwordField;
    private JTextArea resultArea;
    private EncryptionUtil encryptionUtil;

    public EncryptUserInput() {
        initializeUI();
        setupEncryptionProvider();
        encryptionUtil = new EncryptionUtil();
    }

    private void initializeUI() {
        setTitle("Encryption/Decryption Tool");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(500, 400);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(new EmptyBorder(20, 20, 20, 20));

        JPanel inputPanel = new JPanel(new GridBagLayout());
        GridBagConstraints constraints = new GridBagConstraints();
        constraints.insets = new Insets(10, 10, 10, 10);
        constraints.anchor = GridBagConstraints.WEST;

        JLabel usernameLabel = new JLabel("Username:");
        constraints.gridx = 0;
        constraints.gridy = 0;
        inputPanel.add(usernameLabel, constraints);

        usernameField = new JTextField(20);
        constraints.gridx = 1;
        inputPanel.add(usernameField, constraints);

        JLabel passwordLabel = new JLabel("Password:");
        constraints.gridx = 0;
        constraints.gridy = 1;
        inputPanel.add(passwordLabel, constraints);

        passwordField = new JPasswordField(20);
        constraints.gridx = 1;
        inputPanel.add(passwordField, constraints);

        panel.add(inputPanel, BorderLayout.NORTH);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));

        JButton encryptButton = new JButton("Encrypt");
        JButton decryptButton = new JButton("Decrypt");

        buttonPanel.add(encryptButton);
        buttonPanel.add(decryptButton);

        panel.add(buttonPanel, BorderLayout.CENTER);

        JPanel outputPanel = new JPanel(new BorderLayout());
        outputPanel.setBorder(BorderFactory.createTitledBorder("Output"));

        resultArea = new JTextArea(10, 30);
        resultArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(resultArea);
        outputPanel.add(scrollPane, BorderLayout.CENTER);

        panel.add(outputPanel, BorderLayout.SOUTH);

        encryptButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String username = usernameField.getText().trim();
                String password = new String(passwordField.getPassword());

                try {
                    String encryptedUsername = encryptionUtil.encrypt(username);
                    String encryptedPassword = encryptionUtil.encrypt(password);

                    resultArea.setText("Encrypted username: " + encryptedUsername + "\nEncrypted password: " + encryptedPassword);
                    saveEncryptedToDatabase(username, password, encryptedUsername, encryptedPassword);
                    JOptionPane.showMessageDialog(panel, "Encryption successful", "Encryption Result", JOptionPane.INFORMATION_MESSAGE);
                } catch (Exception ex) {
                    resultArea.setText("Error encrypting data: " + ex.getMessage());
                    JOptionPane.showMessageDialog(panel, "Error encrypting data: " + ex.getMessage(), "Encryption Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        decryptButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String encryptedText = resultArea.getText().trim();
                try {
                    String[] lines = encryptedText.split("\n");
                    String encryptedUsername = lines[0].split(": ")[1];
                    String encryptedPassword = lines[1].split(": ")[1];

                    String decryptedUsername = encryptionUtil.decrypt(encryptedUsername);
                    String decryptedPassword = encryptionUtil.decrypt(encryptedPassword);

                    resultArea.setText("Decrypted username: " + decryptedUsername + "\nDecrypted password: " + decryptedPassword);
                    saveDecryptedToDatabase(encryptedUsername, encryptedPassword, decryptedUsername, decryptedPassword);
                    JOptionPane.showMessageDialog(panel, "Decryption successful", "Decryption Result", JOptionPane.INFORMATION_MESSAGE);
                } catch (Exception ex) {
                    resultArea.setText("Error decrypting data: " + ex.getMessage());
                    JOptionPane.showMessageDialog(panel, "Error decrypting data: " + ex.getMessage(), "Decryption Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        add(panel);
        setVisible(true);
    }

    private void setupEncryptionProvider() {
        Security.addProvider(new BouncyCastleProvider());
    }

    private void saveEncryptedToDatabase(String username, String password, String encryptedUsername, String encryptedPassword) {
        String url = "jdbc:mysql://localhost:3306/project";
        String user = "root";
        String pass = "chaoscomesoon";

        String insertQuery = "INSERT INTO encrypted_values (username, password, enc_username, enc_password) VALUES (?, ?, ?, ?)";

        try (Connection conn = DriverManager.getConnection(url, user, pass);
             PreparedStatement pstmt = conn.prepareStatement(insertQuery)) {

            pstmt.setString(1, username);
            pstmt.setString(2, password);
            pstmt.setString(3, encryptedUsername);
            pstmt.setString(4, encryptedPassword);
            pstmt.executeUpdate();
        } catch (SQLException ex) {
            ex.printStackTrace();
            resultArea.setText("Database error: " + ex.getMessage());
        }
    }

    private void saveDecryptedToDatabase(String encryptedUsername, String encryptedPassword, String decryptedUsername, String decryptedPassword) {
        String url = "jdbc:mysql://localhost:3306/project";
        String user = "root";
        String pass = "chaoscomesoon";

        String insertQuery = "INSERT INTO decrypted_values (enc_username, enc_password, dec_username, dec_password) VALUES (?, ?, ?, ?)";

        try (Connection conn = DriverManager.getConnection(url, user, pass);
             PreparedStatement pstmt = conn.prepareStatement(insertQuery)) {

            pstmt.setString(1, encryptedUsername);
            pstmt.setString(2, encryptedPassword);
            pstmt.setString(3, decryptedUsername);
            pstmt.setString(4, decryptedPassword);
            pstmt.executeUpdate();
        } catch (SQLException ex) {
            ex.printStackTrace();
            resultArea.setText("Database error: " + ex.getMessage());
        }
    }

    static class EncryptionUtil {

        private static final String ALGORITHM = "DESede";  // Triple DES (3DES) as an example

        public String encrypt(String data) throws Exception {
            KeyGenerator keyGen = KeyGenerator.getInstance(ALGORITHM, "BC");
            keyGen.init(168); // for Triple DES
            SecretKey secretKey = keyGen.generateKey();

            Cipher cipher = Cipher.getInstance(ALGORITHM, "BC");
            cipher.init(Cipher.ENCRYPT_MODE, secretKey);

            byte[] encryptedData = cipher.doFinal(data.getBytes());

            // Store the secret key and encrypted data as a concatenated base64 string
            byte[] keyAndEncryptedData = concatenate(secretKey.getEncoded(), encryptedData);
            return Base64.getEncoder().encodeToString(keyAndEncryptedData);
        }

        public String decrypt(String encryptedBase64Data) throws Exception {
            byte[] keyAndEncryptedData = Base64.getDecoder().decode(encryptedBase64Data);
            byte[] keyData = extractKey(keyAndEncryptedData);
            byte[] encryptedData = extractEncryptedData(keyAndEncryptedData);

            SecretKey secretKey = new SecretKeySpec(keyData, ALGORITHM);
            Cipher cipher = Cipher.getInstance(ALGORITHM, "BC");
            cipher.init(Cipher.DECRYPT_MODE, secretKey);

            byte[] decryptedData = cipher.doFinal(encryptedData);
            return new String(decryptedData);
        }

        private byte[] concatenate(byte[] key, byte[] data) {
            byte[] combined = new byte[key.length + data.length];
            System.arraycopy(key, 0, combined, 0, key.length);
            System.arraycopy(data, 0, combined, key.length, data.length);
            return combined;
        }

        private byte[] extractKey(byte[] keyAndEncryptedData) {
            return Arrays.copyOfRange(keyAndEncryptedData, 0, 24); // Triple DES key length
        }

        private byte[] extractEncryptedData(byte[] keyAndEncryptedData) {
            return Arrays.copyOfRange(keyAndEncryptedData, 24, keyAndEncryptedData.length);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new EncryptUserInput();
            }
        });
    }
}
